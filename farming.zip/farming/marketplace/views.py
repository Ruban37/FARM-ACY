from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.models import Group
from django.contrib.auth.decorators import login_required

from .models import *
# Create your views here.
from .forms import *

def home(request):
    return render(request, 'marketplace/home.html')

def about(request):
    return render(request, 'marketplace/about.html')

def products(request):
    return render(request, 'marketplace/products.html')

def services(request):
    return render(request, 'marketplace/services.html')

def registerPage(request):
    form = CreateUserForm()

    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')

            
            user_type = request.POST.get('user_type')
            profile, created = Profile.objects.get_or_create(user=user)
            
            if not created:
                profile.user_type = user_type
                profile.save()
            
            messages.success(request,'Account was created for'+username)
            return redirect('login')
        else:
            messages.error(request, 'There was an error with your registration.')

    context={'form':form}
    return render(request,'marketplace/register.html',context)


def loginPage(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request,user)
           # return redirect('home')
            '''
            if user.profile.user_type == 'farmer':
                return redirect('farmer_dashboard')
            elif user.profile.user_type == 'buyer':
                return redirect('buyer_dashboard')
            '''
            try:
                profile = Profile.objects.get(user=user)
                if profile.user_type == 'farmer':
                    return redirect('farmer_dashboard')
                elif profile.user_type == 'buyer':
                    return redirect('buyer_dashboard')
            except Profile.DoesNotExist:
                messages.error(request, 'Profile does not exist for this user.')

        else:
            messages.info(request,'Username OR password is incorrect')

    context={}
    return render(request,'marketplace/login.html',context)

def farmer_dashboard(request):

    return render(request, 'marketplace/farmer_dashboard.html')


def buyer_dashboard(request):

    return render(request,'marketplace/buyer_dashboard.html')

def register_farmer(request):
    if request.method == 'POST':
        form = FarmerRegistrationForm(request.POST)
        if form.is_valid():
            farmer = form.save(commit=False)
            farmer.user = request.user
            farmer.save()
            return redirect('login')

    else:
        form = FarmerRegistrationForm()
    return render(request, 'marketplace/register_farmer.html', {'form':form})

def register_buyer(request):
    if request.method == 'POST':
        form = BuyerRegistrationForm(request.POST)
        if form.is_valid():
            buyer = form.save(commit=False)
            buyer.user = request.user
            buyer.save()
            return redirect('login')

    else:
        form = BuyerRegistrationForm()
    return render(request, 'marketplace/register_buyer.html', {'form': form})

def product_list(request, product_id):
    products = Product.objects.get(id=product_id)
    if request.method == 'POST':
        form = RequestForm(request.POST)
        if form.is_valid():
            req = form.save(commit=False)
            req.buyer = request.user.buyer
            req.product = product
            req.save()
            return redirect('product_list')

    else:
        form = RequestForm()
    return render(request, 'send_request.html',{'form': form, 'product': product})

def send_request(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        form = RequestForm(request.POST)
        if form.is_valid():
            req = form.save(commit=False)
            req.buyer = request.user.buyer
            req.product = product
            req.save()
            return redirect('product_list')
    else:
        form = RequestForm()
    return render(request, 'send_request.html', {'form': form, 'product': product})

def accept_request(request, request_id):
    req = Request.objects.get(id=request_id)
    req.accepted = True
    req.save()
    return redirect('dashboard')

