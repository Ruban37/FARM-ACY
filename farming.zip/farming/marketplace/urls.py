from django.urls import path
from . import views


urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('products/', views.products, name='products'),
    path('services/', views.services, name='services'),
    path('register/', views.registerPage, name='register'),
    path('login/', views.loginPage, name='login'),
    path('farmer_dashboard/', views.farmer_dashboard, name='farmer_dashboard'),
    path('buyer_dashboard/', views.buyer_dashboard, name='buyer_dashboard'),
    path('register/farmer/',views.register_farmer, name = 'register_farmer'),
    path('register/buyer/', views.register_buyer, name='register_buyer'),
    path('products/', views.product_list, name='product_list'),
    path('send_request/<int:product_id>/', views.send_request, name='send_request'),
    path('accept_request/<int:request_id>/', views.accept_request, name='accept_request'),
       
]

'''
    path('about/', views.about, name='about'),
    path('products/', views.products, name='products'),
    path('services/', views.services, name='services'),
    path('contact/', views.contact, name='contact'),
    path('contracts/farmer/', views.farmer_contract_list_view, name='farmer_contract_list'),
    path('contracts/buyer/', views.buyer_contract_list_view, name='buyer_contract_list'),
    path('register/', views.registerPage, name='register'),
    path('login/', views.loginPage, name='login'),
    '''
